import { Component } from '@angular/core';

@Component({
  selector: 'app-movies-index',
  templateUrl: './movies-index.component.html',
  styleUrls: ['./movies-index.component.css']
})
export class MoviesIndexComponent {

}
